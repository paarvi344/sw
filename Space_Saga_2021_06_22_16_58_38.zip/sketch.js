var PLAY = 1;
var END = 0;
var count = 0;

var gameState = PLAY;

var rocket,rocket_moving;
var backGround, bgImg, bg2Img;
var obstacleGroup,obstacleImage;
var goldGroup, goldImg;


var score=0;
var gameOver, restart;
var sound;



function preload(){
  
  //rocket Image
  rocket_moving=loadAnimation("rocket1.png","rocket3.png","rocket4.png");
  
  //background Image
  bgImg=loadImage("bg2.png");
  bg2Img=loadImage("bg1.png");

  
  // Obstacle Image
  obstacleImage = loadImage("rock.png");
 
  gameOverImg = loadImage("gameOver.png");
  restartImg = loadImage("restart.png");
  
  goldImg = loadImage("gold.png");
  
  sound=loadSound("sound.wav")
  
}

function setup() {
  createCanvas(550,450);

  rocket = createSprite(100,100,10,15);
  rocket.addAnimation("moving",rocket_moving);
  rocket.scale = 0.35;
  
  
  gameOver = createSprite(300,100);
  gameOver.addImage(gameOverImg);
  
  
  restart = createSprite(300,175);
  restart.addImage(restartImg);
  
  gameOver.scale = 0.5;
  restart.scale = 0.05;

  gameOver.visible = false;
  restart.visible = false;
  
  obstacleGroup = new Group();
  goldGroup = new Group();

     score=0;

}

function draw() {
  
  background(bgImg);
  
  //display score
  fill("black");
  text("Score: "+ score, 400,50);
  
  text("Count:"+ count,50,50);
  
   if(keyDown(UP_ARROW)){
         rocket.y=rocket.y-5;
        }
  
    if(keyDown(DOWN_ARROW)){
         rocket.y=rocket.y+5;
        }
  
  //if the gameState is in play 
  if (gameState===PLAY){
     spawnObstacles();
     spawnGold();
     sound.play();
    
    if(goldGroup.isTouching(rocket)){
      score= score+10;
      goldGroup.destroyEach();
    }
    if(obstacleGroup.isTouching(rocket)){
      count++
      obstacleGroup.destroyEach();
    }
    if(count===5){
      gameState=END;
    }
    if(score===10||score===30||score===50||score===70||score===90||score===100){
      background(bg2Img);
      }
  }
  else if (gameState === END) {
    gameOver.visible = true;
    restart.visible = true;
    
    //set velcity of each game object to 0
    rocket.y = 100;
    obstacleGroup.setVelocityXEach(0);
  
    //set lifetime of the game objects so that they                 are never destroyed
    obstacleGroup.setLifetimeEach(-1);
    
    if(mousePressedOver(restart)) {
      reset();
    }
  }
  
  drawSprites();
}

function spawnObstacles() {
 if (frameCount % 50 === 0) {
    var obstacle = createSprite(600,120,40,10);
    obstacle.y = Math.round(random(50,200));
    obstacle.addImage(obstacleImage);
    obstacle.velocityX = -3;
  
     obstacle.velocityX = -(6 + 3*score/500);
    
     obstacle.setCollider("circle",0,0,1);
     obstacle.debug=false;
   
    //assign scale and lifetime to the obstacle           
     obstacle.scale = 0.35;
     obstacle.lifetime = 300;
     obstacle.depth = rocket.depth;
     rocket.depth +=1;
     obstacleGroup.add(obstacle);
 }
}
function reset(){
  gameState = PLAY;
  gameOver.visible = false;
  restart.visible = false;
  
  obstacleGroup.destroyEach(); 
  goldGroup.destroyEach();
  rocket.velocity=0;
  
  score = 0;
  
}


function spawnGold() {
 if (frameCount % 130 === 0) {
    var gold = createSprite(600,120,40,10);
    gold.y = Math.round(random(50,200));
    gold.addImage(goldImg);
    gold.scale = 0.15;
    gold.velocityX = -3;
  
     gold.velocityX = -(6 + 3*score/500);
    
     gold.setCollider("circle",0,0,1);
     gold.debug=false;
   
    //assign scale and lifetime to the obstacle           
     gold.scale = 0.15;
     gold.lifetime = 300;
     gold.depth = rocket.depth;
     rocket.depth +=1;
     goldGroup.add(gold);
 }

}